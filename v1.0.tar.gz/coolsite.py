# coolsite.py
import webbrowser

def main():
    url = "https://coolman947.github.io/website-html/#"
    webbrowser.open(url)

if __name__ == "__main__":
    main()

