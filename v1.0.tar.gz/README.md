# Coolsite - Opens a cool website
