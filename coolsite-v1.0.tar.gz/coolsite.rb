class Coolsite < Formula
  desc "Opens a cool website"
  homepage "https://coolman947.github.io/website-html/"
  url "https://github.com/coolman947/coolsite/archive/v1.0.tar.gz"
sha256 "4fde38091f76e7f53c0e8c0d626c3c5bb9627bb2d5ba587f89bbad0633b972bd"
  license "MIT"

  depends_on "python@3.9"

  def install
    bin.install "coolsite.py"
  end

  test do
    system "#{bin}/coolsite.py"
  end
end

